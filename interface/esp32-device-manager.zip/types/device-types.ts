export interface DeviceType {
  id: string
  type: string
  pins: number[]
  state: string
  interfaceType: string
  direction: string
}

